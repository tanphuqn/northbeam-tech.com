<?php

function northbeam_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('align-wide');
    add_theme_support('wp-block-styles');

    register_nav_menus(array(
        'primary' => __('Primary Menu', 'northbeam-technologies'),
        'footer' => __('Footer Menu', 'northbeam-technologies'),
    ));
}
add_action('after_setup_theme', 'northbeam_setup');

/** Appearance → Customize → Social links: footer Facebook, LinkedIn & X URLs. */
function northbeam_customize_register($wp_customize) {
    $wp_customize->add_section('northbeam_social', array(
        'title'    => __('Social links', 'northbeam-technologies'),
        'priority' => 35,
    ));
    $wp_customize->add_setting('northbeam_facebook_url', array(
        'default'           => 'https://www.facebook.com/northbeam-technologies',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('northbeam_facebook_url', array(
        'label'   => __('Facebook URL (footer)', 'northbeam-technologies'),
        'section' => 'northbeam_social',
        'type'    => 'url',
    ));
    $wp_customize->add_setting('northbeam_linkedin_url', array(
        'default'           => 'https://www.linkedin.com/company/northbeam-technologies',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('northbeam_linkedin_url', array(
        'label'   => __('LinkedIn URL (footer)', 'northbeam-technologies'),
        'section' => 'northbeam_social',
        'type'    => 'url',
    ));
    $wp_customize->add_setting('northbeam_x_url', array(
        'default'           => 'https://x.com/northbeam-technologies',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('northbeam_x_url', array(
        'label'   => __('X (Twitter) URL (footer)', 'northbeam-technologies'),
        'section' => 'northbeam_social',
        'type'    => 'url',
    ));
}
add_action('customize_register', 'northbeam_customize_register');

/** Adds layout hooks used by style.css (e.g. services pillar & How We Work images). */
function northbeam_body_class( $classes ) {
    if ( is_page( array( 'service', 'services' ) ) ) {
        $classes[] = 'services-page';
    }
    return $classes;
}
add_filter( 'body_class', 'northbeam_body_class' );

function northbeam_category_nav_current_class( $classes, $menu_item ) {
    if ( ! is_category() ) {
        return $classes;
    }

    $category = get_queried_object();
    if ( ! $category || empty( $category->slug ) ) {
        return $classes;
    }

    $category_to_page = array(
        'blog'     => 'blog',
        'insights' => 'insights',
    );

    if ( empty( $category_to_page[ $category->slug ] ) ) {
        return $classes;
    }

    $page_slug = $category_to_page[ $category->slug ];
    $item_path = untrailingslashit( wp_parse_url( $menu_item->url, PHP_URL_PATH ) );
    $item_slug = trim( $item_path, '/' );

    if ( $item_slug === $page_slug || sanitize_title( $menu_item->title ) === $page_slug ) {
        $classes[] = 'current-menu-item';
    }

    return $classes;
}
add_filter( 'nav_menu_css_class', 'northbeam_category_nav_current_class', 10, 2 );

function northbeam_assets() {
    wp_enqueue_style(
        'northbeam-style',
        get_stylesheet_uri(),
        array(),
        wp_get_theme()->get('Version')
    );
}
add_action('wp_enqueue_scripts', 'northbeam_assets');

function northbeam_seed_menu_notice() {
    if (!current_user_can('manage_options')) {
        return;
    }
    $lines = array();
    if (!has_nav_menu('primary')) {
        $lines[] = __('Assign a menu to "Primary Menu" for the header.', 'northbeam-technologies');
    }
    if (!has_nav_menu('footer')) {
        $lines[] = __('Optionally assign "Footer Menu" to customize the footer; until then, default links are shown.', 'northbeam-technologies');
    }
    if ($lines) {
        add_action('admin_notices', function() use ($lines) {
            echo '<div class="notice notice-info"><p>';
            echo esc_html__('Northbeam theme:', 'northbeam-technologies') . ' ';
            echo esc_html(implode(' ', $lines));
            echo ' ' . esc_html__('Use Appearance → Menus.', 'northbeam-technologies');
            echo '</p></div>';
        });
    }
}
add_action('admin_init', 'northbeam_seed_menu_notice');

/** Allowed tags for inline footer social SVGs. */
function northbeam_social_svg_kses_allowed() {
    return array(
        'svg'  => array(
            'class'       => true,
            'xmlns'       => true,
            'viewBox'     => true,
            'width'       => true,
            'height'      => true,
            'aria-hidden' => true,
            'focusable'   => true,
        ),
        'path' => array(
            'fill' => true,
            'd'    => true,
        ),
    );
}

/** Facebook mark (inline SVG, currentColor). */
function northbeam_social_icon_facebook_svg() {
    return '<svg class="footer-social-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>';
}

/** LinkedIn mark (inline SVG, currentColor). */
function northbeam_social_icon_linkedin_svg() {
    return '<svg class="footer-social-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>';
}

/** X mark (inline SVG, currentColor). */
function northbeam_social_icon_x_svg() {
    return '<svg class="footer-social-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>';
}
